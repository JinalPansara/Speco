package api.com;

public class InvoiceGenerated 
{
	private String invoice;
	private String generatedby;
	private String date;
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public String getGeneratedby() {
		return generatedby;
	}
	public void setGeneratedby(String generatedby) {
		this.generatedby = generatedby;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
